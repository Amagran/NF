# 🚀 Como Publicar o NF Categorizer

## O que você vai precisar

- Uma conta no **GitHub** (gratuita) → github.com
- Uma conta no **Vercel** (gratuita) → vercel.com
- Sua **API Key da Anthropic** → console.anthropic.com

---

## Passo 1: Criar conta no GitHub

1. Acesse **github.com** e clique em **Sign Up**
2. Crie sua conta com email e senha
3. Confirme o email

## Passo 2: Criar o repositório no GitHub

1. No GitHub, clique no botão **+** (canto superior direito) → **New repository**
2. Nome: **nf-categorizer** (ou o nome que quiser)
3. Marque **Private** (para ninguém ver seu código)
4. Clique em **Create repository**

## Passo 3: Fazer upload dos arquivos

Na página do repositório que acabou de criar:

1. Clique em **uploading an existing file** (ou "Add file" → "Upload files")
2. Arraste a pasta descompactada **nf-categorizer-vercel** para dentro
3. Os arquivos devem ficar assim:

```
📁 (raiz do repositório)
├── api/
│   └── ai.js          ← o proxy que esconde sua API key
├── public/
│   └── index.html      ← a aplicação
├── package.json
└── vercel.json
```

⚠️ **IMPORTANTE**: Os arquivos devem ficar na RAIZ do repositório, não dentro de uma subpasta. Se ao fazer upload ficou `nf-categorizer-vercel/api/ai.js`, mova para que fique `api/ai.js` direto na raiz.

4. Clique em **Commit changes**

## Passo 4: Criar conta no Vercel

1. Acesse **vercel.com**
2. Clique em **Sign Up**
3. Escolha **Continue with GitHub** (mais fácil)
4. Autorize o acesso

## Passo 5: Fazer deploy no Vercel

1. No Vercel, clique em **Add New...** → **Project**
2. Ele vai mostrar seus repositórios do GitHub
3. Encontre **nf-categorizer** e clique em **Import**
4. Na tela de configuração:
   - **Framework Preset**: deixe como "Other"
   - **Root Directory**: deixe vazio (raiz)
5. Abra a seção **Environment Variables**
6. Adicione:
   - **Name**: `ANTHROPIC_API_KEY`
   - **Value**: sua API key (começa com `sk-ant-...`)
7. Clique em **Deploy**

## Passo 6: Pronto! 🎉

Após o deploy (leva ~30 segundos), o Vercel vai te dar um link tipo:

**https://nf-categorizer.vercel.app**

Esse é o link que você compartilha com qualquer pessoa! A IA funciona para todos, e sua API key fica segura no servidor.

---

## Dúvidas Comuns

### Quanto custa?
- **Vercel**: gratuito (plano hobby, até 100GB de banda/mês)
- **GitHub**: gratuito
- **API Anthropic**: paga por uso. Cada recategorização de 30 itens custa ~$0.01-0.02

### Como pegar a API Key da Anthropic?
1. Acesse **console.anthropic.com**
2. Crie uma conta
3. Vá em **API Keys** → **Create Key**
4. Copie a chave (começa com `sk-ant-...`)
5. Adicione créditos em **Billing** (mínimo $5)

### E se eu quiser mudar a API key depois?
1. No Vercel, vá em **Settings** → **Environment Variables**
2. Edite o valor de `ANTHROPIC_API_KEY`
3. Clique em **Redeploy** (no painel do projeto)

### Minha key está segura?
Sim! A key fica nas variáveis de ambiente do Vercel. Ninguém que usar o site consegue vê-la. Ela nunca vai para o navegador do usuário.

### Posso limitar quem usa?
Por padrão, qualquer pessoa com o link pode usar. Se quiser restringir, você pode adicionar uma senha no proxy (me peça e eu ajudo).
